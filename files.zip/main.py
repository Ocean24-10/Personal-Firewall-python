#!/usr/bin/env python3
"""
Personal Firewall - main.py
============================
A lightweight personal firewall that:
  1. Sniffs live traffic with scapy
  2. Classifies each packet (protocol, direction, IPs, ports)
  3. Checks it against a rule engine
  4. Logs the ALLOW/BLOCK decision
  5. Optionally enforces persistent BLOCK rules at the kernel level via iptables

Usage:
    sudo python3 main.py monitor                     # live monitor, log only
    sudo python3 main.py monitor --enforce            # also push BLOCK rules to iptables
    python3 main.py list-rules
    python3 main.py add-rule --action BLOCK --dst-port 4444 --protocol TCP --note "Block known malware C2 port"
    python3 main.py remove-rule --id 3
    python3 main.py block-ip 45.33.32.156
    python3 main.py unblock-ip 45.33.32.156
"""

import argparse
import socket
import sys

from rule_engine import RuleEngine
from logger_setup import get_logger
import iptables_utils

try:
    from scapy.all import sniff, IP, TCP, UDP, ICMP
except ImportError:
    print("scapy is required. Install with: pip install scapy --break-system-packages")
    sys.exit(1)

log = get_logger()

# Fill this in with your machine's local IP(s) to determine IN vs OUT.
# We detect it automatically at startup as a sensible default.
def get_local_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        s.close()


LOCAL_IP = get_local_ip()


def classify_packet(pkt) -> dict:
    """Turn a scapy packet into the dict our rule engine understands."""
    if IP not in pkt:
        return None

    proto = "OTHER"
    src_port = "ANY"
    dst_port = "ANY"

    if TCP in pkt:
        proto = "TCP"
        src_port = pkt[TCP].sport
        dst_port = pkt[TCP].dport
    elif UDP in pkt:
        proto = "UDP"
        src_port = pkt[UDP].sport
        dst_port = pkt[UDP].dport
    elif ICMP in pkt:
        proto = "ICMP"

    src_ip = pkt[IP].src
    dst_ip = pkt[IP].dst
    direction = "OUT" if src_ip == LOCAL_IP else "IN"

    return {
        "src_ip": src_ip,
        "dst_ip": dst_ip,
        "src_port": src_port,
        "dst_port": dst_port,
        "protocol": proto,
        "direction": direction,
    }


def make_callback(engine: RuleEngine, enforce: bool):
    def callback(pkt):
        info = classify_packet(pkt)
        if info is None:
            return
        decision = engine.evaluate(info)

        msg = (f"{decision:5s} | {info['direction']:3s} | {info['protocol']:4s} | "
               f"{info['src_ip']}:{info['src_port']} -> {info['dst_ip']}:{info['dst_port']}")

        if decision == "BLOCK":
            log.warning(msg)
            if enforce and iptables_utils.iptables_available():
                target_ip = info["src_ip"] if info["direction"] == "IN" else info["dst_ip"]
                iptables_utils.block_ip(target_ip, direction=info["direction"])
        else:
            log.info(msg)

    return callback


def cmd_monitor(args):
    engine = RuleEngine()
    log.info(f"Personal firewall started. Local IP detected as {LOCAL_IP}")
    log.info(f"Enforcement via iptables: {'ON' if args.enforce else 'OFF (log-only mode)'}")
    if args.enforce and not iptables_utils.iptables_available():
        log.warning("iptables not found - falling back to log-only mode")
        args.enforce = False

    try:
        sniff(prn=make_callback(engine, args.enforce), store=False,
              filter=args.bpf_filter if args.bpf_filter else None)
    except PermissionError:
        log.error("Permission denied. Packet sniffing requires root/administrator privileges.")
        sys.exit(1)
    except KeyboardInterrupt:
        log.info("Firewall stopped by user.")


def cmd_list_rules(args):
    engine = RuleEngine()
    print(f"Default action: {engine.default_action}\n")
    for r in engine.list_rules():
        status = "ENABLED" if r.enabled else "DISABLED"
        print(f"[{r.id}] {r.action:5s} {status:8s} {r.direction:3s} {r.protocol:4s} "
              f"{r.src_ip}:{r.src_port} -> {r.dst_ip}:{r.dst_port}  ({r.note})")


def cmd_add_rule(args):
    engine = RuleEngine()
    rule = engine.add_rule(
        action=args.action,
        direction=args.direction,
        protocol=args.protocol,
        src_ip=args.src_ip,
        dst_ip=args.dst_ip,
        src_port=args.src_port,
        dst_port=args.dst_port,
        note=args.note or "",
    )
    print(f"Added rule [{rule.id}]")


def cmd_remove_rule(args):
    engine = RuleEngine()
    ok = engine.remove_rule(args.id)
    print("Removed." if ok else "No rule with that ID.")


def cmd_block_ip(args):
    ok, out = iptables_utils.block_ip(args.ip, direction=args.direction)
    print(out if not ok else f"Blocked {args.ip} at the kernel level via iptables.")


def cmd_unblock_ip(args):
    ok, out = iptables_utils.unblock_ip(args.ip, direction=args.direction)
    print(out if not ok else f"Unblocked {args.ip}.")


def build_parser():
    p = argparse.ArgumentParser(description="Personal Firewall")
    sub = p.add_subparsers(dest="command", required=True)

    m = sub.add_parser("monitor", help="Start live traffic monitoring")
    m.add_argument("--enforce", action="store_true",
                    help="Also push BLOCK decisions into iptables (real enforcement)")
    m.add_argument("--bpf-filter", default=None,
                    help="Optional BPF filter, e.g. 'tcp or udp'")
    m.set_defaults(func=cmd_monitor)

    lr = sub.add_parser("list-rules", help="List current rules")
    lr.set_defaults(func=cmd_list_rules)

    ar = sub.add_parser("add-rule", help="Add a new rule")
    ar.add_argument("--action", choices=["BLOCK", "ALLOW"], required=True)
    ar.add_argument("--direction", choices=["IN", "OUT", "ANY"], default="ANY")
    ar.add_argument("--protocol", choices=["TCP", "UDP", "ICMP", "ANY"], default="ANY")
    ar.add_argument("--src-ip", default="ANY")
    ar.add_argument("--dst-ip", default="ANY")
    ar.add_argument("--src-port", default="ANY")
    ar.add_argument("--dst-port", default="ANY")
    ar.add_argument("--note", default="")
    ar.set_defaults(func=cmd_add_rule)

    rr = sub.add_parser("remove-rule", help="Remove a rule by ID")
    rr.add_argument("--id", type=int, required=True)
    rr.set_defaults(func=cmd_remove_rule)

    bi = sub.add_parser("block-ip", help="Immediately block an IP via iptables")
    bi.add_argument("ip")
    bi.add_argument("--direction", choices=["IN", "OUT"], default="IN")
    bi.set_defaults(func=cmd_block_ip)

    ui = sub.add_parser("unblock-ip", help="Remove an iptables block for an IP")
    ui.add_argument("ip")
    ui.add_argument("--direction", choices=["IN", "OUT"], default="IN")
    ui.set_defaults(func=cmd_unblock_ip)

    return p


if __name__ == "__main__":
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)
