"""
rule_engine.py
--------------
Handles loading, saving, and matching firewall rules.

A rule looks like:
{
    "id": 1,
    "action": "BLOCK" | "ALLOW",
    "direction": "IN" | "OUT" | "ANY",
    "protocol": "TCP" | "UDP" | "ICMP" | "ANY",
    "src_ip": "1.2.3.4" | "ANY",
    "dst_ip": "1.2.3.4" | "ANY",
    "src_port": 443 | "ANY",
    "dst_port": 443 | "ANY",
    "enabled": true
}

Rules are checked top-to-bottom. First match wins. If nothing matches,
the default policy (default_action in config) applies.
"""

import json
import os
from dataclasses import dataclass, asdict
from typing import List, Optional

RULES_FILE = os.path.join(os.path.dirname(__file__), "rules.json")


@dataclass
class Rule:
    id: int
    action: str          # BLOCK / ALLOW
    direction: str        # IN / OUT / ANY
    protocol: str          # TCP / UDP / ICMP / ANY
    src_ip: str = "ANY"
    dst_ip: str = "ANY"
    src_port: str = "ANY"
    dst_port: str = "ANY"
    enabled: bool = True
    note: str = ""

    def matches(self, pkt_info: dict) -> bool:
        if not self.enabled:
            return False
        if self.direction != "ANY" and self.direction != pkt_info["direction"]:
            return False
        if self.protocol != "ANY" and self.protocol != pkt_info["protocol"]:
            return False
        if self.src_ip != "ANY" and self.src_ip != pkt_info["src_ip"]:
            return False
        if self.dst_ip != "ANY" and self.dst_ip != pkt_info["dst_ip"]:
            return False
        if self.src_port != "ANY" and str(self.src_port) != str(pkt_info["src_port"]):
            return False
        if self.dst_port != "ANY" and str(self.dst_port) != str(pkt_info["dst_port"]):
            return False
        return True


class RuleEngine:
    def __init__(self, rules_file: str = RULES_FILE, default_action: str = "ALLOW"):
        self.rules_file = rules_file
        self.default_action = default_action
        self.rules: List[Rule] = []
        self.load()

    def load(self):
        if not os.path.exists(self.rules_file):
            self.rules = []
            self.save()
            return
        with open(self.rules_file, "r") as f:
            data = json.load(f)
        self.rules = [Rule(**r) for r in data.get("rules", [])]
        self.default_action = data.get("default_action", self.default_action)

    def save(self):
        data = {
            "default_action": self.default_action,
            "rules": [asdict(r) for r in self.rules],
        }
        with open(self.rules_file, "w") as f:
            json.dump(data, f, indent=2)

    def next_id(self) -> int:
        return max([r.id for r in self.rules], default=0) + 1

    def add_rule(self, **kwargs) -> Rule:
        rule = Rule(id=self.next_id(), **kwargs)
        self.rules.append(rule)
        self.save()
        return rule

    def remove_rule(self, rule_id: int) -> bool:
        before = len(self.rules)
        self.rules = [r for r in self.rules if r.id != rule_id]
        self.save()
        return len(self.rules) < before

    def evaluate(self, pkt_info: dict) -> str:
        """Return 'BLOCK' or 'ALLOW' for a given packet-info dict."""
        for rule in self.rules:
            if rule.matches(pkt_info):
                return rule.action
        return self.default_action

    def list_rules(self) -> List[Rule]:
        return self.rules
