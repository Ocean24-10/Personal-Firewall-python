# Personal Firewall (Python)

A lightweight personal firewall that sniffs live network traffic, evaluates
each packet against a configurable rule set, logs every decision, and can
optionally enforce blocks at the kernel level using `iptables` (Linux).

Built as a cybersecurity internship project to demonstrate packet filtering,
protocol analysis, and network security fundamentals.

## Features
- Live packet sniffing with `scapy`
- Rule engine supporting IP, port, protocol, and direction (IN/OUT) matching
- JSON-based rule storage — easy to read, edit, version control
- Rotating log files (audit trail of every ALLOW/BLOCK decision)
- Optional real enforcement via `iptables` (not just logging)
- Simple CLI: add rules, remove rules, block/unblock IPs on the fly

## Architecture
```
personal_firewall/
├── main.py            # CLI entry point + packet sniffer loop
├── rule_engine.py      # Rule model + matching logic
├── iptables_utils.py    # Wrapper for real iptables enforcement
├── logger_setup.py      # Rotating file + console logging
├── rules.json           # Your rule set (editable)
└── requirements.txt
```

## Setup

1. **Requirements**: Linux (recommended, for iptables), Python 3.8+, root access.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt --break-system-packages
   ```
   (drop `--break-system-packages` on Windows/macOS or inside a venv)
3. On Windows: packet sniffing still works via scapy + Npcap
   (install [Npcap](https://npcap.com/) first), but the `iptables_utils.py`
   module won't work — for real enforcement, swap it for `netsh advfirewall`
   calls or the WinAPI Filtering Platform.

## Usage

**Start monitoring (log-only, safe default):**
```bash
sudo python3 main.py monitor
```

**Start monitoring AND enforce blocks via iptables:**
```bash
sudo python3 main.py monitor --enforce
```

**List current rules:**
```bash
python3 main.py list-rules
```

**Add a rule** (e.g. block a known malicious port):
```bash
python3 main.py add-rule --action BLOCK --protocol TCP --dst-port 4444 --note "Block known malware C2 port"
```

**Remove a rule:**
```bash
python3 main.py remove-rule --id 3
```

**Instantly block/unblock an IP (bypasses the rule engine, direct iptables call):**
```bash
sudo python3 main.py block-ip 45.33.32.156
sudo python3 main.py unblock-ip 45.33.32.156
```

## How it works
1. `main.py` captures packets live with `scapy.sniff()`.
2. Each packet is normalized into a dict (`src_ip`, `dst_ip`, ports, protocol, direction).
3. `RuleEngine.evaluate()` checks the packet against rules top-to-bottom;
   first match wins, otherwise the default action applies.
4. The decision is logged. If `--enforce` is passed and the decision is `BLOCK`,
   the source/destination IP is pushed into `iptables` so the kernel drops
   future packets from/to it — not just this one.

## Testing it safely
- Run in log-only mode first (`monitor` without `--enforce`) so you can see
  what would be blocked before you actually block it.
- Try adding a rule to block port 23 (Telnet) or 4444 (a common test/malware port)
  and confirm it shows `BLOCK` in the logs.
- Check `logs/firewall.log` for the full audit trail.

## Notes for the internship writeup
- This demonstrates: packet capture, protocol analysis (TCP/UDP/ICMP),
  rule-based filtering (similar to how real firewalls like iptables/pf work),
  and OS-level enforcement.
- Suggested extensions if you want to go further: a Flask/Tkinter dashboard,
  GeoIP-based blocking, rate-limiting/DoS detection, whitelisting by
  process name (via `psutil`).

## Disclaimer
For educational and personal use on networks/systems you own or are
authorized to monitor. Do not deploy against traffic you don't have
permission to inspect.
