"""
iptables_utils.py
------------------
Thin wrapper around iptables so the firewall can enforce BLOCK
decisions at the kernel level, not just log them.

Requires: Linux, root privileges, iptables installed.
On Windows, swap this module for a WinAPI / netsh advfirewall
implementation (see README for pointers).
"""

import subprocess
import shutil

CHAIN_COMMENT = "personal_firewall"


def _run(cmd):
    """Run a shell command, return (success, output)."""
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        return True, result.stdout
    except subprocess.CalledProcessError as e:
        return False, e.stderr
    except FileNotFoundError:
        return False, "iptables not found on this system"


def iptables_available() -> bool:
    return shutil.which("iptables") is not None


def block_ip(ip: str, direction: str = "IN"):
    """
    Add a persistent DROP rule for an IP address.
    direction: IN -> INPUT chain, OUT -> OUTPUT chain
    """
    chain = "INPUT" if direction == "IN" else "OUTPUT"
    flag = "-s" if direction == "IN" else "-d"
    cmd = [
        "iptables", "-A", chain, flag, ip,
        "-m", "comment", "--comment", CHAIN_COMMENT,
        "-j", "DROP",
    ]
    return _run(cmd)


def unblock_ip(ip: str, direction: str = "IN"):
    chain = "INPUT" if direction == "IN" else "OUTPUT"
    flag = "-s" if direction == "IN" else "-d"
    cmd = [
        "iptables", "-D", chain, flag, ip,
        "-m", "comment", "--comment", CHAIN_COMMENT,
        "-j", "DROP",
    ]
    return _run(cmd)


def block_port(port: int, protocol: str = "tcp", direction: str = "IN"):
    chain = "INPUT" if direction == "IN" else "OUTPUT"
    port_flag = "--dport" if direction == "IN" else "--sport"
    cmd = [
        "iptables", "-A", chain, "-p", protocol.lower(), port_flag, str(port),
        "-m", "comment", "--comment", CHAIN_COMMENT,
        "-j", "DROP",
    ]
    return _run(cmd)


def unblock_port(port: int, protocol: str = "tcp", direction: str = "IN"):
    chain = "INPUT" if direction == "IN" else "OUTPUT"
    port_flag = "--dport" if direction == "IN" else "--sport"
    cmd = [
        "iptables", "-D", chain, "-p", protocol.lower(), port_flag, str(port),
        "-m", "comment", "--comment", CHAIN_COMMENT,
        "-j", "DROP",
    ]
    return _run(cmd)


def list_firewall_rules():
    """List only the rules this tool added (tagged with our comment)."""
    ok, out = _run(["iptables", "-L", "-v", "-n"])
    if not ok:
        return ok, out
    lines = [l for l in out.splitlines() if CHAIN_COMMENT in l or l.startswith("Chain")]
    return True, "\n".join(lines)


def flush_firewall_rules():
    """
    Remove all rules added by this tool (best-effort).
    Re-reads the rule list and deletes matching lines.
    NOTE: iptables has no 'delete by comment' shortcut, so for a clean
    slate in testing, consider running a dedicated chain instead (see README).
    """
    ok, out = _run(["iptables-save"])
    if not ok:
        return ok, out
    removed = 0
    for line in out.splitlines():
        if CHAIN_COMMENT in line and line.startswith("-A"):
            parts = line.split()
            parts[0] = "-D"
            _run(["iptables"] + parts)
            removed += 1
    return True, f"Removed {removed} rule(s)"
