# Password Cracking & Hashing Algorithms

An educational project exploring how password hashing works, why unsalted
hashes are vulnerable, and how dictionary and brute-force attacks recover
weak passwords. Built as part of a cybersecurity internship assignment.

> ⚠️ **Ethical use only.** This project only attacks hashes it generates
> itself, locally, from a list of intentionally weak test passwords. Never
> run cracking tools against accounts, systems, or hash dumps you don't own
> or have explicit written authorization to test.

## What this demonstrates

- How common hash functions (MD5, SHA-1, SHA-256, SHA-512) turn a password
  into a fixed-length digest, and why that's *not* the same as encryption.
- Why **unsalted** hashes are weak: identical passwords always produce
  identical hashes, so an attacker can precompute a dictionary once and
  reuse it against any leaked hash list.
- Why **salting** (adding a unique random value before hashing) defeats
  precomputed dictionaries and rainbow tables — the same password produces
  a different hash for every user.
- Two classic cracking strategies:
  - **Dictionary attack** — try every word in a wordlist (fast, works well
    against real-world weak passwords).
  - **Brute-force attack** — exhaustively try every combination of
    characters up to a given length (guaranteed to work eventually, but
    grows exponentially with length/charset size).

## Project structure

```
password-cracking-project/
├── hash_utils.py              # hashing + salting + verification helpers
├── generate_sample_hashes.py  # creates test accounts & hashes them
├── cracker.py                 # dictionary + brute-force cracker (CLI)
├── wordlists/
│   └── common_passwords.txt   # sample wordlist of common weak passwords
├── sample_hashes/             # generated hash files (created by script)
└── README.md
```

## Setup

Requires Python 3.8+. No external dependencies — everything uses the
standard library (`hashlib`, `itertools`, `argparse`).

```bash
git clone https://github.com/<your-username>/password-cracking-project.git
cd password-cracking-project
```

## Usage

### 1. Generate test hashes

Creates unsalted MD5, unsalted SHA-256, and salted SHA-256 hash files for
five test accounts with deliberately weak passwords:

```bash
python3 generate_sample_hashes.py
```

### 2. Run a dictionary attack (unsalted hashes)

```bash
python3 cracker.py --hashes sample_hashes/unsalted_md5.json \
                    --mode dictionary \
                    --algorithm md5 \
                    --wordlist wordlists/common_passwords.txt
```

### 3. Run a dictionary attack against salted hashes

```bash
python3 cracker.py --hashes sample_hashes/salted_sha256.json \
                    --mode dictionary \
                    --algorithm sha256 \
                    --salted \
                    --wordlist wordlists/common_passwords.txt
```

### 4. Run a brute-force attack

```bash
python3 cracker.py --hashes sample_hashes/unsalted_md5.json \
                    --mode bruteforce \
                    --algorithm md5 \
                    --charset abcdefghijklmnopqrstuvwxyz0123456789 \
                    --max-length 4
```

`--max-length` controls how long a password brute force will attempt.
Keep it small (3–5) for a demo — the search space grows exponentially
(`len(charset) ^ length` guesses).

### Example output

```
Loaded 5 target hash(es) from sample_hashes/unsalted_md5.json
[dictionary] Tried 16 candidates in 0.000s (93727 guesses/sec)

=== Results ===
  CRACKED  alice: password123
  CRACKED  erin: qwerty
  CRACKED  bob: letmein
  CRACKED  carol: dragon
  CRACKED  dave: Summer2024!
```

## Using real tools: Hashcat & John the Ripper

This Python implementation is for learning the underlying mechanics. In
practice, security professionals use purpose-built, GPU-accelerated tools.
To extend this project:

**John the Ripper** (dictionary attack on the MD5 dump):
```bash
john --wordlist=wordlists/common_passwords.txt --format=raw-md5 sample_hashes/dump_md5.txt
john --show sample_hashes/dump_md5.txt
```

**Hashcat** (mode `0` = raw MD5):
```bash
hashcat -m 0 -a 0 sample_hashes/dump_md5.txt wordlists/common_passwords.txt
hashcat -m 0 sample_hashes/dump_md5.txt --show
```

## Key takeaways / findings

- All five unsalted test passwords were cracked in under a second with a
  30-word dictionary — real attacker wordlists contain millions of entries.
- Salting did **not** prevent the dictionary attack in this demo (since we
  still tried each candidate against each salt individually), but it *does*
  prevent precomputed/rainbow-table attacks and makes cracking many hashes
  at once far more expensive, since no work can be reused across users.
- Brute force succeeds on short passwords almost instantly but becomes
  computationally infeasible quickly as length/charset grow — this is the
  core argument for long, unpredictable passwords over short "clever" ones.
- Slow, purpose-built hashing algorithms (bcrypt, scrypt, Argon2) — not
  shown here — are the real-world defense, because they're deliberately
  expensive per guess, unlike fast general-purpose hashes like MD5/SHA-256.

## Disclaimer

Created for educational purposes as part of a cybersecurity internship.
All target data was generated locally by this project's own scripts. No
real user credentials, systems, or third-party data were involved.
